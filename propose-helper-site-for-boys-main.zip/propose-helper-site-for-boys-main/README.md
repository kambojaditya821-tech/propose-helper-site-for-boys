# propose-helper-site-for-boys
A romantic Valentine proposal website 💖 with floating heart animations, background music, and a WhatsApp response button. Built using HTML, CSS, and JavaScript.
